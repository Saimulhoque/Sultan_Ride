package com.example.sultanride;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_details);
    }
}
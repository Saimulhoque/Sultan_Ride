package com.example.sultanride;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OTP_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_activity);
    }
}